import './js/common';
//import './js/anime';
import './css/main.css';
import './scss/main.scss';
import './scss/test.scss';
import './scss/animejs.scss';
//import './js/anime-test';
import './js/react-test.jsx'

import 'bootstrap/dist/css/bootstrap.min.css';
